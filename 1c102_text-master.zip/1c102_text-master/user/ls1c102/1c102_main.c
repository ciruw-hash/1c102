/*
    i2c-oled接线
    //  VCC     接 3.3v 电源
    //  GND     电源地
    //  SCL     GPIO4 （时钟）
    //  SDA     GPIO5 （数据）
    注意：i2c显示有关内容占两行，y=0,2,4,6
*/
#include "ls1x.h"
#include "Config.h"
#include "oled96.h"
#include "ls1c102_i2c.h"
#include "ls1x_latimer.h"
#include "ls1x_gpio.h"
#include "BEEP.h"
#include "LED.h"
#include "dht11.h"
#include "ls1x_uart.h"
#include "ls1c102_ptimer.h"
#include "UserGpio.h"
// 温湿度相关变量
char str [30];               // 温湿度显示字符串缓冲区

uint8_t uart_temp_flag = 0;  // 串口发送温湿度标志
int temp_temp;              // 温度校准值（原始温度 + 5，用于串口发送）
uint8_t display_updated = 0; // 温湿度显示更新标志
uint32_t tick_count = 200;     // 系统滴答计数器（时间基准）
uint8_t warning_flash_flag = 0; // 报警闪烁标志


uint16_t temp_raw, humi_raw;    // 原始温湿度值


// 温度报警控制函数
void Temp_Alarm_Control(void) {
    if (temp_raw > 250) { // 使用原始值比较(25℃=250)
        // 温度高于 25 度：蜂鸣器报警，LED 闪烁（根据闪烁标志）
        BEEP_ON;
        LED1_CTRL(warning_flash_flag);  // LED 点亮
        
    } else {
        // 温度低于等于 25 度：关闭蜂鸣器和 LED
        BEEP_OFF;
        LED1_CTRL(0);
    }
}

int main(int arg, char *args []) {
    
    // 初始化系统与外设
    SystemClockInit();       // 系统时钟初始化
    GPIOInit();              // GPIO 初始化
    LED_init();              // LED 初始化（使用专用初始化函数）
    EnableInt();             // 开启总中断
    OLED_Init();             // OLED 显示屏初始化
    OLED_Full();// OLED全屏变白
    OLED_Clear();  // 清屏
    while (DHT11_Init());     // 初始化 DHT11 温湿度传感器（失败则等待）
    OLED_Full();// OLED全屏变白

   
        
  

    
    while (1) {
       
        
        
            // 若需要更新显示，刷新 OLED
            DHT11_Read_Data(&temp_raw, &humi_raw);
            OLED_Clear();  // 清屏
            
            // 显示温度（转换为实际值：原始值/10）
            char temp_str[20];
            sprintf(temp_str, "Temp=%d", temp_raw / 10);
            OLED_ShowString(0, 0, temp_str);  // x=0, y=0（第0行）
            
            // 显示湿度（转换为实际值：原始值/10）
            char humi_str[20];
            sprintf(humi_str, "Humi=%d%% ", humi_raw / 10);
            OLED_ShowString(0, 2, humi_str);  // x=0, y=2（第2行，间隔1行避免重叠）
            
            // 温度高于25℃时，闪烁显示报警信息
            if (temp_raw > 250 && warning_flash_flag) {  // 25℃对应原始值250
                OLED_ShowString(0, 4, "WARNING! HIGH TEMP");  // x=0, y=4（第4行）
            }
            
            // 温度报警控制
        Temp_Alarm_Control();
        delay_ms(2000); 
        warning_flash_flag ^= 1;
        
        
    }
}
