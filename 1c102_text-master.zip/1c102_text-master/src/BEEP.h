#ifndef _BEEP_H
#define _BEEP_H
#include "ls1x_gpio.h"
#include "ls1x.h"

#define BEEP GPIO_PIN_63

#define BEEP_ON  gpio_write_pin(BEEP,GPIO_HIGH)
#define BEEP_OFF gpio_write_pin(BEEP,GPIO_LOW)


#endif