#include "LED.h"


void LED_init(){

    gpio_set_direction(LED1,1);//设置gpio输入输出


}