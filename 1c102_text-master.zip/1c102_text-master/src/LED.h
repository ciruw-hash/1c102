#ifndef _LED_H
#define _LED_H
#include "ls1x_gpio.h"
#include "ls1x.h"
#define LED1 GPIO_PIN_16


#define LED1_CTRL(x)  gpio_write_pin(LED1,x)

void LED_init();
#endif